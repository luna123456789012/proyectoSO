CREATE TABLE cartas(ID_c INT NOT NULL,
					color TEXT,
					numero INT,
					total INT,
					sobran INT
					) ENGINE = InnoDB;

INSERT INTO cartas (ID_c, color, numero, total, sobran) VALUES
	(1, 'rojo', 0, 3, 3),
	(2, 'rojo', 1, 3, 3),
	(3, 'rojo', 2, 3, 3),
	(4, 'rojo', 3, 3, 3),
	(5, 'rojo', 4, 3, 3),
	(6, 'rojo', 5, 3, 3),
	(7, 'rojo', 6, 3, 3),
	(8, 'rojo', 7, 3, 3),
	(9, 'rojo', 8, 3, 3),
	(10, 'rojo', 9, 3, 3),

	(11, 'amarillo', 0, 3, 3),
	(12, 'amarillo', 1, 3, 3),
	(13, 'amarillo', 2, 3, 3),
	(14, 'amarillo', 3, 3, 3),
	(15, 'amarillo', 4, 3, 3),
	(16, 'amarillo', 5, 3, 3),
	(17, 'amarillo', 6, 3, 3),
	(18, 'amarillo', 7, 3, 3),
	(19, 'amarillo', 8, 3, 3),
	(20, 'amarillo', 9, 3, 3),
	
	
	(21, 'verde', 0, 3, 3),
	(22, 'verde', 1, 3, 3),
	(23, 'verde', 2, 3, 3),
	(24, 'verde', 3, 3, 3),
	(25, 'verde', 4, 3, 3),
	(26, 'verde', 5, 3, 3),
	(27, 'verde', 6, 3, 3),
	(28, 'verde', 7, 3, 3),
	(29, 'verde', 8, 3, 3),
	(30, 'verde', 9, 3, 3),
	
	(31, 'azul', 0, 3, 3),
	(32, 'azul', 1, 3, 3),
	(33, 'azul', 2, 3, 3),
	(34, 'azul', 3, 3, 3),
	(35, 'azul', 4, 3, 3),
	(36, 'azul', 5, 3, 3),
	(37, 'azul', 6, 3, 3),
	(38, 'azul', 7, 3, 3),
	(39, 'azul', 8, 3, 3),
	(40, 'azul', 9, 3, 3);
	
