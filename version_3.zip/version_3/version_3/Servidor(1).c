#include <mysql/mysql.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <pthread.h>
#include <errno.h>


#define MAX_USUARIOS 100


typedef struct {
    int socket;
    char usuario[50];
} UsuarioConectado;


UsuarioConectado usuarios[MAX_USUARIOS];
int num_usuarios = 0;
pthread_mutex_t usuarios_mutex;


MYSQL* ConectarSQL() {
    MYSQL *conn = mysql_init(NULL);
    if (conn == NULL) {
        printf("Error al inicializar la conexion.\n");
        return NULL;
    }
    if (mysql_real_connect(conn, "localhost", "root", "mysql", "juego", 0, NULL, 0) == NULL) {
        printf("Error al conectar a MySQL: %s\n", mysql_error(conn));
        mysql_close(conn);
        return NULL;
    }
    return conn;
}


void AgregarUsuario(int socket, const char* usuario) {
    pthread_mutex_lock(&usuarios_mutex);
    if (num_usuarios < MAX_USUARIOS) {
        strncpy(usuarios[num_usuarios].usuario, usuario, sizeof(usuarios[num_usuarios].usuario) - 1);
        usuarios[num_usuarios].usuario[sizeof(usuarios[num_usuarios].usuario) - 1] = '\0';
        usuarios[num_usuarios].socket = socket;
        num_usuarios++;
    } else {
        printf("Se alcanzo el numero maximo de usuarios.\n");
    }
    pthread_mutex_unlock(&usuarios_mutex);
}


// Funciￃﾳn para eliminar un usuario de forma segura (con mutex).
void EliminarUsuario(int socket) {
    pthread_mutex_lock(&usuarios_mutex);
    for (int i = 0; i < num_usuarios; i++) {
        if (usuarios[i].socket == socket) {
            for (int j = i; j < num_usuarios - 1; j++) {
                usuarios[j] = usuarios[j + 1];
            }
            num_usuarios--;
            break;
        }
    }
    pthread_mutex_unlock(&usuarios_mutex);
}




// Funciￃﾳn auxiliar para eliminar un usuario sin bloquear el mutex (se asume bloqueo ya adquirido)
void EliminarUsuarioSinLock(int socket) {
    for (int i = 0; i < num_usuarios; i++) {
        if (usuarios[i].socket == socket) {
            for (int j = i; j < num_usuarios - 1; j++) {
                usuarios[j] = usuarios[j + 1];
            }
            num_usuarios--;
            break;
        }
    }
}

void RegistrarUsuario(int sock_conn, MYSQL *conn, char *usuario, char *contrasena) {
    char consulta[256], respuesta[512];
    snprintf(consulta, sizeof(consulta), "SELECT COUNT(*) FROM jugadores WHERE usuario = '%s'", usuario);
    if (mysql_query(conn, consulta)) {
        snprintf(respuesta, sizeof(respuesta), "Error en consulta");
    } else {
        MYSQL_RES *res = mysql_store_result(conn);
        if (res == NULL) {
            snprintf(respuesta, sizeof(respuesta), "Error en resultado");
        } else {
            MYSQL_ROW row = mysql_fetch_row(res);
            if (row != NULL && atoi(row[0]) > 0) {
                snprintf(respuesta, sizeof(respuesta), "EXISTE");
            } else {
                snprintf(consulta, sizeof(consulta), "INSERT INTO jugadores (usuario, contrase�a) VALUES ('%s', '%s')", usuario, contrasena);
                if (mysql_query(conn, consulta)) {
                    snprintf(respuesta, sizeof(respuesta), "Error en insercion");
                } else {
                    snprintf(respuesta, sizeof(respuesta), "OK");
                }
            }
            mysql_free_result(res);
        }
    }
    write(sock_conn, respuesta, strlen(respuesta));
}

void LoginUsuario(int sock_conn, MYSQL *conn, char *usuario, char *contrasena) {
    char consulta[256], respuesta[512];
    snprintf(consulta, sizeof(consulta), "SELECT COUNT(*) FROM jugadores WHERE usuario = '%s' AND contrase�a = '%s'", usuario, contrasena);
    if (mysql_query(conn, consulta)) {
        snprintf(respuesta, sizeof(respuesta), "Error en consulta de login");
    } else {
        MYSQL_RES *res = mysql_store_result(conn);
        if (res == NULL) {
            snprintf(respuesta, sizeof(respuesta), "Error en resultado de login");
        } else {
            MYSQL_ROW row = mysql_fetch_row(res);
            if (row != NULL && atoi(row[0]) > 0) {
                AgregarUsuario(sock_conn, usuario);
                snprintf(respuesta, sizeof(respuesta), "Login exitoso");
            } else {
                snprintf(respuesta, sizeof(respuesta), "ERROR");
            }
            mysql_free_result(res);
        }
    }
    write(sock_conn, respuesta, strlen(respuesta));
}

void DarCartasIniciales(int sock_conn, MYSQL *conn) {
	char consulta[256];
	snprintf(consulta, sizeof(consulta), 
			 "SELECT ID_c, color, numero FROM cartas WHERE sobran > 0 ORDER BY RAND() LIMIT 7;");
	printf("Ejecutando consulta: %s\n", consulta);
	if (mysql_query(conn, consulta) != 0) {
		char error_msg[] = "6/Error en la consulta SQL";
		write(sock_conn, error_msg, strlen(error_msg));
		return;
	}
	MYSQL_RES *resultado = mysql_store_result(conn);
	if (!resultado) {
		char error_msg[] = "6/Error al obtener el resultado SQL";
		write(sock_conn, error_msg, strlen(error_msg));
		return;
	}
	MYSQL_ROW fila;
	char respuesta[512] = "6/";
	while ((fila = mysql_fetch_row(resultado))) {
		if (fila[0] && fila[1] && fila[2]) { // Validar que los valores no sean NULL
			char carta[50];
			snprintf(carta, sizeof(carta), "%s,%s,%s;", fila[0], fila[1], fila[2]);
			strcat(respuesta, carta);
		}
	}
	mysql_free_result(resultado);
	write(sock_conn, respuesta, strlen(respuesta));
}
	

void DarCarta (int sock_conn, MYSQL *conn) {
	char consulta[256];
	snprintf(consulta, sizeof(consulta), "SELECT ID_c, color, numero FROM cartas WHERE sobran > 0 ORDER BY RAND() LIMIT 1;");
	printf("Ejecutando consulta: %s\n", consulta);
	if (mysql_query(conn, consulta) == 0) {
		MYSQL_RES *resultado = mysql_store_result(conn);
		MYSQL_ROW fila;
		if ((fila = mysql_fetch_row(resultado)) != NULL) {
			char respuesta[512] = "7/";
			char carta[50];
			snprintf(carta, sizeof(carta), "%s,%s,%s;", fila[0], fila[1], fila[2]);
			strcat(respuesta, carta);
			if (respuesta[strlen(respuesta) - 1] == ';') {
				respuesta[strlen(respuesta) - 1] = '\0';
			}
			write(sock_conn, respuesta, strlen(respuesta));
			mysql_free_result(resultado);
/*			int id_carta = atoi(fila[0]);*/
/*			CartaEnUso(conn, id_carta);*/
			
		} 
	} else {
		char error_msg[] = "7/Error en la consulta SQL";
		write(sock_conn, error_msg, strlen(error_msg));
	}
}

/*void CartaEnUso(MYSQL *conn, int ID_carta){*/
/*	char consulta[256];*/
/*	snprintf(consulta, sizeof(consulta), "UPDATE cartas SET sobran = sobran - 1 WHERE ID_c = %d;", ID_carta);*/
/*	char respuesta[512];*/
/*	if (mysql_query(conn, consulta) == 0) {*/
/*		snprintf(respuesta, sizeof(respuesta), "Carta seleccionada correctamente. El campo 'sobran' se ha actualizado.");*/
/*	} else {*/
/*		snprintf(respuesta, sizeof(respuesta), "Error al actualizar la carta: %s", mysql_error(conn));*/
/*	}*/
/*}*/

void *AtenderCliente(void *arg) {
    int sock_conn = *((int *)arg);
    free(arg);
    char peticion[512], respuesta[512];
    int ret;
    while (1) {
        memset(peticion, 0, sizeof(peticion));
        ret = read(sock_conn, peticion, sizeof(peticion) - 1);
        if (ret <= 0) {
            if (ret < 0) perror("Error en read");
            else printf("Cliente desconectado\n");
            EliminarUsuario(sock_conn);
            break;
        }
        peticion[ret] = '\0';
        char *p = strtok(peticion, "/");
        if (p == NULL) {
            snprintf(respuesta, sizeof(respuesta), "Formato de peticion incorrecto");
            write(sock_conn, respuesta, strlen(respuesta));
            continue;
        }
        int codigo = atoi(p);
        MYSQL *conn = ConectarSQL();
        if (conn == NULL) {
            snprintf(respuesta, sizeof(respuesta), "Error de conexion a la base de datos");
            write(sock_conn, respuesta, strlen(respuesta));
            continue;
        }
        if (codigo == 2) {
            char *usuario = strtok(NULL, "/");
            char *contrasena = strtok(NULL, "/");
            if (usuario && contrasena) RegistrarUsuario(sock_conn, conn, usuario, contrasena);
            else {
                snprintf(respuesta, sizeof(respuesta), "Datos insuficientes para registro");
                write(sock_conn, respuesta, strlen(respuesta));
            }
        } else if (codigo == 3) {
            char *usuario = strtok(NULL, "/");
            char *contrasena = strtok(NULL, "/");
            if (usuario && contrasena) LoginUsuario(sock_conn, conn, usuario, contrasena);
            else {
                snprintf(respuesta, sizeof(respuesta), "Datos insuficientes para login");
                write(sock_conn, respuesta, strlen(respuesta));
            }
        } else if (codigo == 6) {
            DarCartasIniciales(sock_conn, conn);
        }else if (codigo == 7) {
			DarCarta(sock_conn, conn);
		}else {
            snprintf(respuesta, sizeof(respuesta), "Codigo desconocido");
            write(sock_conn, respuesta, strlen(respuesta));
        }
        mysql_close(conn);
    }
    close(sock_conn);
    return NULL;
}

int ConexionC(int puerto) {
	int sock_listen, sock_conn;
	struct sockaddr_in serv_adr;
	
	
	sock_listen = socket(AF_INET, SOCK_STREAM, 0);
	if (sock_listen < 0) {
		perror("Error al crear el socket");
		return -1;
	}
	
	int optval = 1;
	if (setsockopt(sock_listen, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval)) < 0) {
		perror("Error al configurar SO_REUSEADDR");
		close(sock_listen);
		return -1;
	}
	memset(&serv_adr, 0, sizeof(serv_adr));
	serv_adr.sin_family = AF_INET;
	serv_adr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_adr.sin_port = htons(puerto);
	
	if (bind(sock_listen, (struct sockaddr *)&serv_adr, sizeof(serv_adr)) < 0) {
		perror("Error en bind");
		close(sock_listen);
		return -1;
	}
	if (listen(sock_listen, 3) < 0) {
		perror("Error en listen");
		close(sock_listen);
		return -1;
	}
	printf("Servidor escuchando en el puerto %d...\n", puerto);
	
	while (1) {
		sock_conn = accept(sock_listen, NULL, NULL);
		if (sock_conn < 0) {
			perror("Error en accept");
			continue;
		}
		printf("Cliente conectado\n");
		
		pthread_t tid;
		int *pclient = malloc(sizeof(int));
		if (pclient == NULL) {
			perror("Error al asignar memoria para el socket del cliente");
			close(sock_conn);
			continue;
		}
		*pclient = sock_conn;
		if (pthread_create(&tid, NULL, AtenderCliente, pclient) != 0) {
			perror("Error al crear el hilo");
			free(pclient);
			close(sock_conn);
			continue;
		}
		pthread_detach(tid);
	}
	close(sock_listen);
	return 0;
}

int main() {
    if (pthread_mutex_init(&usuarios_mutex, NULL) != 0) {
        perror("Error al inicializar el mutex");
        return -1;
    }
    int puerto = 9050;
    int result = ConexionC(puerto);
    pthread_mutex_destroy(&usuarios_mutex);
    return result;
}
