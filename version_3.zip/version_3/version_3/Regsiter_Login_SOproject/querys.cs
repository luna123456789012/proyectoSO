﻿using System;
using System.Drawing;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.IO;

namespace Regsiter_Login_SOproject
{
    public partial class Querys : Form
    {
        private Socket server;
        private string usuarioActual;

        private bool conectado;
        private Thread escuchaThread;


        private PictureBox currentPictureBox;
        private Point mouseOffset;

        private System.Windows.Forms.Timer tiempo;

        public Querys(Socket serverSocket, string usuario, bool conectado)
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
            this.server = serverSocket;
            this.usuarioActual = usuario;
            this.conectado = conectado;
        }

        private void Querys_Load(object sender, EventArgs e)
        {
            ThreadStart ts = delegate { EscucharServidor (); };
            escuchaThread = new Thread(ts);
            escuchaThread.IsBackground = true;
            escuchaThread.Start();

            tiempo = new System.Windows.Forms.Timer();
            tiempo.Interval = 1000; // 2000 milisegundos = 2 segundos
            tiempo.Tick += Temporizador_Tick;
            tiempo.Start();
        }

        private void Temporizador_Tick(object sender, EventArgs e)
        {
            tiempo.Stop(); // Para que solo se ejecute una vez

            // Acción a realizar después de 2 segundos
            string mensaje = "6/";
            byte[] msg = Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }
        private void Querys_close(object sender, EventArgs e)
        {
            escuchaThread.Abort();
        }

//PROCEDIMIENTO DE REPARTO INICIAL DE CARTAS
        private void CargarCartasIniciales(string respuesta)
        {
            try
            {
                string[] partes = respuesta.Split('/');
                if (partes.Length > 1)
                {
                    string[] cartas = partes[1].Split(';');
                    MostrarCartas(cartas);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar cartas: " + ex.Message);
            }
        }
        //PROCEDIMIENTO PARA MOSTRAR LAS CARTAS EN LA PANTALLA
        private void MostrarCartas(string[] cartas)
        {
            panel.Controls.Clear(); // Limpiar panel antes de mostrar las nuevas cartas

            int x = 10;
            int y = 10;
            int separacion = 110;

            foreach (string carta in cartas)
            {
                if (!string.IsNullOrWhiteSpace(carta))
                {
                    string[] datosCarta = carta.Split(','); // [ID, Color, Número]
                    if (datosCarta.Length == 3)
                    {
                        string nombreArchivo = $"{datosCarta[2]}{datosCarta[1]}.png";
                        string rutaCompleta = Path.Combine(Application.StartupPath, "cartas", nombreArchivo);
                        if (System.IO.File.Exists(rutaCompleta)) // Verificar si la imagen existe
                        {
                            PictureBox pic = new PictureBox
                            {
                                Image = Image.FromFile(rutaCompleta),
                                SizeMode = PictureBoxSizeMode.StretchImage,
                                Width = 100,
                                Height = 150,
                                Location = new Point(x, y),
                                Margin = new Padding(5)
                            };
                            pic.MouseDown += PictureBox_MouseDown;
                            pic.MouseMove += PictureBox_MouseMove;
                            pic.MouseUp += PictureBox_MouseUp;

                            panel.Controls.Add(pic); // Agregar la imagen al panel

                            x += separacion;
                            if (x + 100 > panel.Width)
                            {
                                x = 10;
                                y += 160;
                            }
                        }
                        else
                        {
                            MessageBox.Show($"No se encontró la imagen: {nombreArchivo}");
                        }
                    }
                }
            }
        }

        private void PictureBox_MouseDown(object sender, MouseEventArgs e)
        {
            currentPictureBox = sender as PictureBox;
            mouseOffset = e.Location;
        }

        private void PictureBox_MouseMove(object sender, MouseEventArgs e)
        {
            if (currentPictureBox != null && e.Button == MouseButtons.Left)
            {
                currentPictureBox.Left += e.X - mouseOffset.X;
                currentPictureBox.Top += e.Y - mouseOffset.Y;
            }
        }

        private void PictureBox_MouseUp(object sender, MouseEventArgs e)
        {
            currentPictureBox = null;
        }



        //THREAD ESCUCHA DEL SERVIDOR

        private void EscucharServidor()
        {
            while (conectado)
            {
                try
                {
                    byte[] buffer = new byte[2048];
                    int bytesRecibidos = server.Receive(buffer);
                    string respuesta = Encoding.ASCII.GetString(buffer, 0, bytesRecibidos).Trim();

                    this.Invoke((MethodInvoker)delegate
                    {
                        ProcesarRespuesta(respuesta);
                    });
                }
                catch
                {
                    conectado = false;
                    this.Invoke((MethodInvoker)delegate 
                    {
                        MessageBox.Show("Conexión cerrada por el servidor.");
                        this.Close();
                    });
                }
            }
        }

        private void ProcesarRespuesta(string respuesta)
        {
            try
            {
                if (respuesta.StartsWith("NOT"))
                {
                    try
                    {
                        string[] partes = respuesta.Split(':');
                        string notificacion = partes[1];

                        if (!string.IsNullOrWhiteSpace(notificacion))
                        {
                            Notificaciones.Items.Add(notificacion);
                        }                          
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al recibir la notificaciones del servidor: " + ex.Message);
                    }
                }
                if (respuesta.StartsWith("4/"))
                {
                    try
                    {
                        string[] partes = respuesta.Split('/');
                        string jugadores = partes[1];

                        // Lista de usuarios conectados
                        listBoxUsuarios.Items.Clear();
                        string[] usuarios = jugadores.Split('\n');

                        foreach (string usuario in usuarios)
                            if (!string.IsNullOrWhiteSpace(usuario))
                                listBoxUsuarios.Items.Add(usuario);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al obtener usuarios: " + ex.Message);
                    }
                }
                else if (respuesta.StartsWith("5/"))
                {
                    try
                    {
                        string[] partes = respuesta.Split('/');
                        string mensajeDesconexion = partes[1];
                        // Confirmación de cierre de sesión
                        MessageBox.Show(mensajeDesconexion);
                        conectado = false;

                        server.Shutdown(SocketShutdown.Both);
                        server.Close();

                        this.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al cerrar sesión: " + ex.Message);
                    }
                }

                else if (respuesta.StartsWith("6/"))
                {
                    CargarCartasIniciales(respuesta);
                }
                else if (respuesta.StartsWith("7/"))
                {
                    try
                    {
                        // Carta recibida
                        string[] datosCarta = respuesta.Split(',');
                        if (datosCarta.Length == 3)
                        {
                            string nombreArchivo = $"{datosCarta[2]}{datosCarta[1]}.png";
                            string rutaCompleta = Path.Combine(Application.StartupPath, "cartas", nombreArchivo);

                            if (System.IO.File.Exists(rutaCompleta)) // Verificar si la imagen existe
                            {
                                PictureBox pic = new PictureBox
                                {
                                    Image = Image.FromFile(rutaCompleta),
                                    SizeMode = PictureBoxSizeMode.StretchImage,
                                    Width = 100,
                                    Height = 150,
                                    Margin = new Padding(5),
                                };

                                pic.MouseDown += PictureBox_MouseDown;
                                pic.MouseMove += PictureBox_MouseMove;
                                pic.MouseUp += PictureBox_MouseUp;

                                panel.Controls.Add(pic); // Agregar la imagen al panel
                            }
                            else
                            {
                                MessageBox.Show($"No se encontró la imagen: {nombreArchivo}");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al pedir carta: " + ex.Message);
                    }
                }
            }
            catch
            {
                MessageBox.Show($"Mensaje no reconocido: {respuesta}");
            }
            
        }


        private void btnVerUsuarios_Click(object sender, EventArgs e)
        {
            string mensaje = "4/";
            byte[] msg = Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }

        private void btnCerrarSesion_Click(object sender, EventArgs e)
        {
            if (server == null || !server.Connected)
            {
                MessageBox.Show("No estás conectado al servidor.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
   
            string mensaje = $"5/{usuarioActual}";
            byte[] msg = Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);           
        }

        private void button1_Click(object sender, EventArgs e)
        {
                string mensaje = "7/";
                byte[] msg = Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);               
        }
    }
}
