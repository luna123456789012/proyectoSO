"Proyecto del grupo 2 de Sistemas Operativos (2024-25-Q1)" 
"UNO" 
"Versi¢n 1 generada por Luna"
"Versi¢n 2 generada por Luna"
Versión 2 comunicada por Mario Carretero
 URL: https://youtu.be/qR48AWhW2Bo